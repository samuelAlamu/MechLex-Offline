"use strict";

/**
 * MechLex 8 — Embedded Base Knowledge Catalog (mechlex-data.js)
 * 
 * קובץ זה הוא קטלוג הבסיס שמוטמע בחבילת האופליין.
 * לאחר ההפעלה הראשונה, עריכות המשתמש נשמרות אוטומטית בדפדפן המקומי
 * ומקבלות קדימות על פני קטלוג הבסיס. להעברה או לשחזור משתמשים בגיבוי JSON מלא.
 */

window.MECHLEX_SHARED_DATA = [
  {
    id: "domain-gdt",
    name: "מידות וטולרנסים גאומטריים",
    nameEn: "Geometric Dimensioning & Tolerancing",
    prefix: "GDT",
    icon: "gdt",
    color: "#1d6885",
    description: "שפה הנדסית להגדרת גאומטריה מותרת, דאטומים, אזורי טולרנס ודרישות פונקציונליות של חלקים והרכבות.",
    subtopics: [
      { id: "subtopic-gdt-datums", name: "דאטומים", description: "מישורי, צירי ונקודות ייחוס תאורטיים", color: "#1d6885", children: [] },
      { id: "subtopic-gdt-form", name: "טולרנסי צורה", description: "בקרת צורה עצמאית ללא דאטום", color: "#2b6e9e", children: [] },
      { id: "subtopic-gdt-location", name: "טולרנסי מיקום", description: "בקרת מיקום ומרכז מאפיינים", color: "#166534", children: [] },
      { id: "subtopic-gdt-material", name: "מצבי חומר", description: "מודיפיירים MMC, LMC וגבול וירטואלי", color: "#854d0e", children: [] }
    ],
    items: [
      {
        id: "term-gdt-001", code: "GDT-001", name: "דאטום", nameEn: "Datum", subtopic: "דאטומים",
        aliases: ["בסיס ייחוס", "Datum Reference"], symbol: "A / B / C", units: "ללא יחידות", difficulty: "בסיסי",
        short: "ייחוס תאורטי מדויק שממנו מגדירים מיקום, כיוון או סיבוב של מאפיינים אחרים.",
        definition: "דאטום הוא מישור, ציר, קו או נקודה תאורטיים מדויקים, הנגזרים ממאפיין דאטום ממשי בחלק. מערכת הדאטומים קובעת כיצד החלק מיוצב במרחב וכיצד יש לפרש ולבדוק טולרנסים גאומטריים ביחס לפונקציה שלו בהרכבה.",
        definitionHtml: "<h3>מושג יסוד ב-GD&amp;T</h3><p><strong>דאטום</strong> הוא מישור, ציר או נקודה תאורטיים מדויקים, הנגזרים ממאפיין דאטום ממשי בחלק. מערכת הדאטומים קובעת כיצד החלק מיוצב במרחב ביחס לפונקציה שלו בהרכבה.</p>",
        why: "ללא מערכת ייחוס עקבית, ייצור ובחינה עלולים להתבצע מנקודות שונות ולתת תוצאות סותרות. בחירה נכונה של דאטומים מדמה את אופן הקיבוע וההעמסה האמיתיים של החלק.",
        formula: "Datum Reference Frame = A | B | C", formulaNote: "סדר הדאטומים מגדיר קדימות: ראשי, משני ושלישוני.",
        variables: [{ symbol: "A", meaning: "דאטום ראשי — מגביל בדרך כלל שלוש דרגות חופש", unit: "—" }, { symbol: "B", meaning: "דאטום משני — מגביל שתי דרגות חופש נוספות", unit: "—" }, { symbol: "C", meaning: "דאטום שלישוני — מגביל את דרגת החופש האחרונה", unit: "—" }],
        uses: ["הגדרת מסגרת ייחוס לבדיקת מיקום חורים", "קביעת אופן הצבת חלק ב-CMM", "תכנון מתקני דפינה ובחינה"],
        cautions: ["אין לבחור דאטום רק לפי נוחות השרטוט; הבחירה צריכה לשקף ממשק פונקציונלי.", "מאפיין דאטום ממשי אינו הדאטום התאורטי עצמו."],
        standards: ["ASME Y14.5", "ISO 5459"],
        manufacturing: "יש ליצור משטחי ייחוס יציבים ונגישים לדפינה. משטח דאטום קטן, לא רציף או גמיש עלול לייצר חזרתיות נמוכה.",
        inspection: "ניתן לממש את מערכת הדאטומים באמצעות פלטה, פינים, V-block או יישור מתמטי במכונת מדידה קואורדינטית.",
        tags: ["GD&T", "Reference Frame", "CMM", "Fixture"], related: ["GDT-002"],
        visualTitle: "מסגרת ייחוס תלת־מישורית", visualDescription: "הדאטום הראשי A מייצב את החלק, B מכוון אותו ו-C משלים את הקיבוע.", updatedAt: "2026-07-21"
      },
      {
        id: "term-gdt-002", code: "GDT-002", name: "טולרנס מיקום", nameEn: "Position Tolerance", subtopic: "טולרנסי מיקום",
        aliases: ["True Position", "מיקום אמיתי"], symbol: "⌖", units: "mm", difficulty: "בינוני",
        short: "בקרת מיקום של ציר, מישור אמצע או מרכז מאפיין ביחס למיקום התאורטי המדויק.",
        definition: "טולרנס מיקום מגדיר אזור טולרנס שבתוכו חייב להימצא הציר או המרכז הנגזר של מאפיין גודל. עבור חור גלילי, אזור הטולרנס הוא לרוב גליל שקוטרו מצוין במסגרת בקרת המאפיין.",
        definitionHtml: "<h3>בקרת מיקום פונקציונלית</h3><p><strong>טולרנס מיקום</strong> מגדיר אזור טולרנס שבתוכו חייב להימצא הציר או המרכז הנגזר של מאפיין גודל. מבטיח הרכבה חליפית ומרווח ברגים תקין.</p>",
        why: "זהו אחד הכלים המרכזיים להבטחת הרכבה חליפית בין חלקים, משום שהוא משלב שליטה במיקום ובמקרים רבים גם בכיוון המאפיין.",
        formula: "TP = 2 · √(Δx² + Δy²)", formulaNote: "נוסחת חישוב סטייה דיאמטרלית במישור עבור דוגמה פשוטה.",
        variables: [{ symbol: "TP", meaning: "סטיית מיקום דיאמטרלית", unit: "mm" }, { symbol: "Δx", meaning: "סטייה בציר X מהמיקום התאורטי", unit: "mm" }, { symbol: "Δy", meaning: "סטייה בציר Y מהמיקום התאורטי", unit: "mm" }],
        uses: ["תבניות חורים לברגים", "מיקום פינים ומיסבים", "שליטה בקואקסיאליות פונקציונלית"],
        cautions: ["אין להשוות ישירות סטייה חד־צירית לקוטר אזור הטולרנס.", "יש לבדוק האם קיים מצב חומר MMC/LMC שמשנה את הטולרנס הזמין."],
        standards: ["ASME Y14.5", "ISO 1101"],
        manufacturing: "קידוח בקואורדינטות, עיבוד במרכז CNC ושימוש בדאטומים יציבים מפחיתים הצטברות שגיאות מיקום.",
        inspection: "CMM, מד־גובה על משטח ייחוס, גייג' פונקציונלי או מדידה אופטית.",
        tags: ["Position", "Hole Pattern", "CMM", "Assembly"], related: ["GDT-001"],
        example: { title: "חישוב סטיית מיקום", given: "מרכז החור סטה ב-Δx = 0.03 mm וב-Δy = 0.04 mm.", solution: "TP = 2 · √(0.03² + 0.04²) = 2 · 0.05", result: "TP = 0.10 mm" },
        visualTitle: "אזור טולרנס גלילי", visualDescription: "ציר החור בפועל חייב להימצא בתוך גליל במיקום התאורטי המדויק.", updatedAt: "2026-07-21"
      }
    ]
  },
  {
    id: "domain-mechanics",
    name: "מכניקה וחוזק חומרים",
    nameEn: "Mechanics & Strength of Materials",
    prefix: "MEC",
    icon: "mechanics",
    color: "#7c4b1f",
    description: "מאמצים, עיבורים, קשיחות, כפיפה, יציבות והתנהגות מכנית של רכיבים תחת עומס.",
    subtopics: [
      { id: "subtopic-mec-stress", name: "מאמץ ועיבור", description: "תגובת החומר לעומסים ציריים", color: "#7c4b1f", children: [] },
      { id: "subtopic-mec-elasticity", name: "אלסטיות", description: "מודול יאנג והתנהגות ליניארית", color: "#a8532a", children: [] },
      { id: "subtopic-mec-bending", name: "כפיפה", description: "מומנט כפיפה ומאמצים בקורות", color: "#b45309", children: [] }
    ],
    items: [
      {
        id: "term-mec-001", code: "MEC-001", name: "מאמץ נורמלי", nameEn: "Normal Stress", subtopic: "מאמץ ועיבור",
        aliases: ["מאמץ צירי"], symbol: "σ", units: "Pa, MPa", difficulty: "בסיסי",
        short: "כוח נורמלי ליחידת שטח חתך, במתיחה או בלחיצה.",
        definition: "מאמץ נורמלי ממוצע מתאר את עוצמת הכוח הפנימי הפועל בניצב לחתך. בהעמסה צירית מרכזית ובהנחות של התפלגות אחידה, הוא מתקבל מחלוקת הכוח הצירי בשטח החתך.",
        definitionHtml: "<h3>מאמץ צירי פנימי</h3><p><strong>מאמץ נורמלי</strong> מתאר את עוצמת הכוח הפנימי הפועל בניצב לחתך. מתקבל מחלוקת הכוח הצירי בשטח החתך הנושא עומס.</p>",
        why: "זהו מדד בסיסי להשוואה בין העומס הפועל לבין חוזק החומר, והוא משמש בתכן מוטות, ברגים, עמודים וחיבורים.",
        formula: "σ = F / A", formulaNote: "הנוסחה מייצגת מאמץ ממוצע; ריכוזי מאמץ דורשים מודל מפורט יותר.",
        variables: [{ symbol: "σ", meaning: "מאמץ נורמלי", unit: "Pa או MPa" }, { symbol: "F", meaning: "כוח צירי", unit: "N" }, { symbol: "A", meaning: "שטח חתך נושא עומס", unit: "m² או mm²" }],
        uses: ["בדיקת מוט מתיחה", "תכן בורג", "בדיקת עמוד בלחיצה"],
        cautions: ["יש לשמור עקביות יחידות: N/mm² שווה MPa.", "בקרבת חורים והברגות המאמץ המקומי גבוה יותר."],
        standards: ["Mechanics of Materials"],
        manufacturing: "שינויים חדים בחתך ופגמי פני שטח מעלים ריכוז מאמץ ומפחיתים חיי עייפות.",
        inspection: "בדיקת ממדים, אימות חומר ומדידת עיבורים תחת עומס.",
        tags: ["Stress", "Axial Load", "Strength"], related: ["MEC-003"],
        example: { title: "מוט במתיחה", given: "כוח F = 20 kN, שטח A = 200 mm².", solution: "σ = 20,000 / 200", result: "σ = 100 MPa" },
        visualTitle: "מוט תחת עומס צירי", visualDescription: "כוחות ציריים הפוכים יוצרים מאמץ נורמלי בחתך.", updatedAt: "2026-07-21"
      },
      {
        id: "term-mec-003", code: "MEC-003", name: "מודול יאנג", nameEn: "Young's Modulus", subtopic: "אלסטיות",
        aliases: ["מודול אלסטיות"], symbol: "E", units: "Pa, GPa", difficulty: "בינוני",
        short: "שיפוע עקומת מאמץ–עיבור בתחום האלסטי הליניארי ומדד לקשיחות החומר.",
        definition: "מודול יאנג הוא היחס בין מאמץ נורמלי לעיבור בתחום שבו ההתנהגות בקירוב ליניארית ואלסטית. ערך גבוה מציין חומר קשיח יותר.",
        definitionHtml: "<h3>מדד קשיחות החומר</h3><p><strong>מודול יאנג</strong> הוא היחס בין מאמץ לעיבור בתחום האלסטי. מבטא את התנגדות החומר לדפורמציה אלסטית.</p>",
        why: "המודול משפיע על שקיעה, סטייה, תדרים טבעיים וחלוקת עומסים.",
        formula: "E = σ / ε", formulaNote: "תקף בתחום האלסטי הליניארי.",
        variables: [{ symbol: "E", meaning: "מודול יאנג", unit: "Pa או GPa" }, { symbol: "σ", meaning: "מאמץ נורמלי", unit: "Pa" }, { symbol: "ε", meaning: "עיבור", unit: "—" }],
        uses: ["חישוב שקיעת קורות", "חישוב התארכות מוט", "מודלים אלסטיים ב-FEA"],
        cautions: ["חומר חזק אינו בהכרח קשיח יותר.", "המודול משתנה עם הטמפרטורה."],
        standards: ["ISO 6892", "ASTM E111"],
        manufacturing: "עיבוד מנוני משנה את חוזק הכניעה יותר מאשר את מודול יאנג.",
        inspection: "ניסוי מתיחה עם מדידת עיבור מדויקת.",
        tags: ["Elasticity", "Stiffness", "Material Property"], related: ["MEC-001"],
        visualTitle: "שיפוע התחום האלסטי", visualDescription: "E הוא השיפוע הליניארי הראשוני בעקומת מאמץ–עיבור.", updatedAt: "2026-07-21"
      }
    ]
  },
  {
    id: "domain-flow",
    name: "זרימה ומערכות נוזלים",
    nameEn: "Fluid Flow & Systems",
    prefix: "FLD",
    icon: "flow",
    color: "#2b6e9e",
    description: "ספיקה, משטרי זרימה, הפסדי לחץ והתנהגות של נוזלים וגזים בצנרת ובמערכות.",
    subtopics: [
      { id: "subtopic-fld-flowrate", name: "ספיקה", description: "מעבר נפח או מסה ביחידת זמן", color: "#2b6e9e", children: [] },
      { id: "subtopic-fld-regime", name: "משטר זרימה", description: "מספר ריינולדס וזרימה למינרית/טורבולנטית", color: "#0369a1", children: [] }
    ],
    items: [
      {
        id: "term-fld-001", code: "FLD-001", name: "ספיקה נפחית", nameEn: "Volumetric Flow Rate", subtopic: "ספיקה",
        aliases: ["ספיקה", "Flow Rate"], symbol: "Q", units: "m³/s, L/min", difficulty: "בסיסי",
        short: "נפח זורם העובר דרך חתך נתון ביחידת זמן.",
        definition: "ספיקה נפחית מתארת את קצב מעבר הנפח דרך חתך. בזרימה חד־ממדית ממוצעת היא שווה למהירות הממוצעת כפול שטח החתך.",
        definitionHtml: "<h3>קצב מעבר נפח</h3><p><strong>ספיקה נפחית</strong> היא נפח הזורם העובר דרך חתך ביחידת זמן. שווה למכפלת שטח החתך במהירות הממוצעת.</p>",
        why: "הספיקה קובעת קיבולת מערכת, זמני מילוי, מהירויות בצנרת, הפסדי לחץ והספקי משאבות.",
        formula: "Q = A·v", formulaNote: "לשדה מהירות לא אחיד הספיקה היא אינטגרל על פני החתך.",
        variables: [{ symbol: "Q", meaning: "ספיקה נפחית", unit: "m³/s" }, { symbol: "A", meaning: "שטח חתך הזרימה", unit: "m²" }, { symbol: "v", meaning: "מהירות ממוצעת", unit: "m/s" }],
        uses: ["בחירת קוטר צינור", "אפיון משאבה", "חישוב זמן מילוי"],
        cautions: ["יש להבחין בין ספיקה נפחית לספיקה מסית."],
        standards: ["ISO 5167"],
        manufacturing: "חספוס פנימי וחיבורים משפיעים על המהירות ועל הפסדי הלחץ.",
        inspection: "מד ספיקה, מדידת הפרש לחץ או מדידה נפחית מכוילת.",
        tags: ["Flow", "Pipe", "Pump"], related: ["FLD-002"],
        example: { title: "ספיקה בצינור", given: "שטח A = 0.002 m², מהירות v = 3 m/s.", solution: "Q = 0.002 · 3", result: "Q = 0.006 m³/s = 6 L/s" },
        visualTitle: "מאזן זרימה בחתך", visualDescription: "הספיקה מתקבלת ממכפלת שטח החתך במהירות הממוצעת.", updatedAt: "2026-07-21"
      },
      {
        id: "term-fld-002", code: "FLD-002", name: "מספר ריינולדס", nameEn: "Reynolds Number", subtopic: "משטר זרימה",
        aliases: ["Re"], symbol: "Re", units: "ללא יחידות", difficulty: "בינוני",
        short: "מספר חסר ממד המבטא את היחס בין כוחות אינרציה לכוחות צמיגות.",
        definition: "מספר ריינולדס משמש לאפיון משטר הזרימה ולהערכת הנטייה לזרימה למינרית, מעברית או טורבולנטית.",
        definitionHtml: "<h3>אפיון משטר זרימה</h3><p><strong>מספר ריינולדס</strong> מדרג את היחס בין כוחות אינרציה לכוחות צמיגות וקובע אם הזרימה היא למינרית או טורבולנטית.</p>",
        why: "משטר הזרימה משפיע על הפסדי לחץ, מעבר חום, ערבוב ורעש.",
        formula: "Re = ρ·v·D / μ", formulaNote: "בצינור לא עגול משתמשים בקוטר הידראולי.",
        variables: [{ symbol: "ρ", meaning: "צפיפות הזורם", unit: "kg/m³" }, { symbol: "v", meaning: "מהירות", unit: "m/s" }, { symbol: "D", meaning: "קוטר צינור", unit: "m" }, { symbol: "μ", meaning: "צמיגות דינמית", unit: "Pa·s" }],
        uses: ["בחירת מקדם חיכוך", "תכנון מעבר חום", "השוואת ניסוי למודל"],
        cautions: ["תכונות הזורם צריכות להילקח בטמפרטורת העבודה."],
        standards: ["Fluid Mechanics"],
        manufacturing: "אי-עגילות וחספוס יכולים להקדים מעבר לטורבולנציה.",
        inspection: "חישוב מתוך ספיקה וקוטר או מדידות הפרשי לחץ.",
        tags: ["Reynolds", "Laminar", "Turbulent"], related: ["FLD-001"],
        visualTitle: "משטרי זרימה בצינור", visualDescription: "ב-Re נמוך הזרימה מסודרת; ב-Re גבוה מופיעות מערבולות.", updatedAt: "2026-07-21"
      }
    ]
  },
  {
    id: "domain-prod",
    name: "הנדסת חומרים ותהליכי ייצור",
    nameEn: "Materials & Manufacturing Engineering",
    prefix: "PROD",
    icon: "manufacturing",
    color: "#10b981",
    description: "שיטות ייצור מתקדמות, עיבוד שבבי, חיתוך בלייזר וטכנולוגיות עיבוד חומרים.",
    subtopics: [
      { id: "subtopic-prod-machining", name: "עיבוד שבבי וזיווד", description: "תהליכי הסרת שבב, כרסום וחיתוך מדויק", color: "#10b981", children: [] }
    ],
    items: [
      {
        id: "term-prod-001", code: "PROD-001", name: "כרסום CNC (CNC Milling)", nameEn: "CNC Milling Process", subtopic: "עיבוד שבבי וזיווד",
        aliases: ["כרסום", "Milling Process"], symbol: "CNC", units: "mm/min, RPM", difficulty: "בינוני",
        short: "תהליך עיבוד שבבי מבוקר מחשב המסיר חומר מגוש גלם באמצעות כלי חיתוך מסתובב ליצירת חלקים גאומטריים מדויקים.",
        definition: "כרסום CNC הוא תהליך ייצור שבו כלי חיתוך מסתובב בכמה צירים (3, 4 או 5 צירים) ומסיר חומר מחומרי גלם מתכתיים או פלסטיים לפי קובץ תיב\"מ (CAD/CAM).",
        definitionHtml: "<h3>עיבוד שבבי ממוחשב</h3><p><strong>כרסום CNC</strong> הוא תהליך ייצור מתקדם המסיר חומר מגוש גלם באמצעות כלי חיתוך מסתובב מבוקר מחשב, המבטיח דיוק גבוה ודיוק גאומטרי תלת־מימדי.</p>",
        why: "מאפשר לייצר רכיבים מכניים מורכבים בטולרנסים הדוקים, חזרתיות גבוהה וגימור פני שטח איכותי.",
        formula: "Vf = fz · z · n", formulaNote: "מהירות הקדמה כתלוי בהזנה לשן, מספר שיניים ומהירות סיבוב.",
        variables: [{ symbol: "Vf", meaning: "מהירות הקדמה", unit: "mm/min" }, { symbol: "fz", meaning: "הזנה לשן", unit: "mm/tooth" }, { symbol: "z", meaning: "מספר שיני החיתוך", unit: "—" }, { symbol: "n", meaning: "מהירות סיבוב הציקלינדר", unit: "RPM" }],
        uses: ["ייצור חלקים מוטסים ורפואיים", "זיווד אלקטרוני ומארזי אלומיניום", "תבניות ודגמים הנדסיים"],
        cautions: ["יש להקפיד על קשיחות הדפינה ורדיוס פינות פנימיות.", "תכנון נכון של כיוון הסיבים ושיטות הקירור."],
        standards: ["ISO 2768-mK", "ASME Y14.5"],
        manufacturing: "שימוש בכרסומים מתאימים לסוג החומר, עיבוד מקדים (Roughing) ועיבוד סופי (Finishing).",
        inspection: "מדידת ממדים ומיקום באמצעות CMM, מד גובה ומיקרומטר.",
        tags: ["CNC", "Milling", "Machining", "Manufacturing"], related: ["PROD-002", "GDT-001"],
        visualTitle: "תהליך כרסום ממוחשב", visualDescription: "כלי החיתוך מסיר שבבים מגוש הגלם ליצירת המבנה הרצוי.", updatedAt: "2026-07-22"
      },
      {
        id: "term-prod-002", code: "PROD-002", name: "חיתוך בלייזר (Laser Cutting)", nameEn: "Laser Beam Cutting", subtopic: "עיבוד שבבי וזיווד",
        aliases: ["חיתוך לייזר", "Laser Cutting"], symbol: "LBC", units: "mm, kW", difficulty: "בסיסי",
        short: "טכנולוגיית חיתוך ממוחשבת המשתמשת בקרן לייזר בעוצמה גבוהה לחיתוך מדויק של פחים וצינורות בטולרנס גבוה.",
        definition: "חיתוך בלייזר עושה שימוש באנרגיה ממוקדת של קרן לייזר (Fiber או CO2) להתכת החומר ונידוף השבבים באמצעות גז עזר (חנקן או חמצן), ליצירת קווי חיתוך נקיים ומדויקים.",
        definitionHtml: "<h3>חיתוך פחים בלייזר</h3><p><strong>חיתוך בלייזר</strong> מבוסס על קרן אנרגיה ממוקדת המתיכה את החומר ויוצרת מתווה חיתוך נקי, מהיר ומדויק ללא מגע מכני ישיר בחלק.</p>",
        why: "מספק מהירות חיתוך גבוהה, אפס בלאי כלי מכני, גמישות מלאה בשינויי תכנון ועובי חיתוך רחב.",
        formula: "E = P / v", formulaNote: "אנרגיה ליחידת אורך כתלוי בהספק הלייזר ומהירות החיתוך.",
        variables: [{ symbol: "E", meaning: "אנרגיה ליחידת אורך", unit: "J/mm" }, { symbol: "P", meaning: "הספק קרן הלייזר", unit: "kW" }, { symbol: "v", meaning: "מהירות החיתוך", unit: "mm/s" }],
        uses: ["חיתוך פחי אלומיניום, נירוסטה ופלדה", "ייצור שלדות ומבנים מרותכים", "חיתוך צינורות ופרופילים"],
        cautions: ["חום החיתוך מייצר אזור מושפע חום (HAZ) דק בקצוות.", "יש להתחשב בעובי קרן החיתוך (Kerf Width)."],
        standards: ["ISO 9013"],
        manufacturing: "סידור אופטימלי של החלקים על גבי הפח (Nesting) לחיסכון בחומר גלם.",
        inspection: "בדיקת אנכיות קו החיתוך, ניקוי גרדים ומדידת אופטיקה.",
        tags: ["Laser", "SheetMetal", "Cutting", "Nesting"], related: ["PROD-001"],
        visualTitle: "קרן לייזר חותכת פח מתכת", visualDescription: "מיקוד הקרן מתיך את החומר וגז העזר מפנה את השבב.", updatedAt: "2026-07-22"
      }
    ]
  }
];
